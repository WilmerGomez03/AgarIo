package WebService;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import ServerModel.ServerModel;

public class HiloDespliegueAppWeb extends Thread {
	
	ServerWeb server;
	
	public HiloDespliegueAppWeb(ServerWeb server) {
		
		this.server = server;
	}
	
	public void run() {
		
		while(server.isWebService()) {
			System.out.println(":::Web Server Started:::");
			ServerSocket serverSocket = server.getServerSocketWebService();
			try {
				Socket cliente = serverSocket.accept();
				ServerWebClientAccept hilo = new ServerWebClientAccept(cliente, server);
				hilo.start();	
				
			} catch (IOException e) {
				System.out.println("Exception in HiloDespliegueAppWeb");
			}
			
		}
		
	}
	

}
