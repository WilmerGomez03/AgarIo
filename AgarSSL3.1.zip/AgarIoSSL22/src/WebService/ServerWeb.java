package WebService;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import View.Session;

public class ServerWeb {
	
	public static final int PORT_WEB_SERVICE = 7000;
	private ServerSocket ServerSocketWebService;
	private boolean webService;
	private HiloDespliegueAppWeb appWeb;
	public ServerWeb() {
		try {
			setServerSocketWebService(new ServerSocket(PORT_WEB_SERVICE));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		setWebService(true);
		appWeb=new HiloDespliegueAppWeb(this);
		appWeb.start();
	}
	public boolean isWebService() {
		return webService;
	}
	public void setWebService(boolean webService) {
		this.webService = webService;
	}
	public ServerSocket getServerSocketWebService() {
		return ServerSocketWebService;
	}
	public void setServerSocketWebService(ServerSocket serverSocketWebService) {
		ServerSocketWebService = serverSocketWebService;
	}
	public ArrayList<String> mensajeSalida(String id, String pass) throws IOException {
		System.out.println("archivo");
		ArrayList<String> lista=new ArrayList<>();
		File archivo = null;
	    FileReader fr = null;
	    BufferedReader br = null;
	    
	    // Apertura del fichero y creacion de BufferedReader para poder
        // hacer una lectura comoda (disponer del metodo readLine()).
	      
	    archivo = new File ("./data/archivo.txt"); //RUTA DONDE SE SUPONE SE VA A GUARDAR EL TXT EN EL SERVIDOR
        fr = new FileReader (archivo);
        br = new BufferedReader(fr);
        
     // Lectura del fichero
         String linea;
         linea = br.readLine();
         boolean seEncontroUsuario = false;
         boolean errorPassword=false;
        
         while(linea!=null&&!seEncontroUsuario&&!errorPassword) {
        	 //Vamos buscando usuario y contrase�a
        	 String[] datos = linea.split(";");
        	
        	 if(datos[2].equals(id)) {
        		 if(datos[1].equals(pass)) {
        			 System.out.println("encontrado");
        			 //AQUI VA EL CODIGO PARA INICIAR EL JUEGO (Abrir la pesta�a del juego)
        			seEncontroUsuario = true;
        			File archivo2 = null;
        		    FileReader fr2 = null;
        		    BufferedReader br2 = null;
        		    
        		    // Apertura del fichero y creacion de BufferedReader para poder
        	        // hacer una lectura comoda (disponer del metodo readLine()).
        		      
        		    archivo2 = new File ("./DBRecords/"+datos[0]); //RUTA DONDE SE SUPONE SE VA A GUARDAR EL TXT EN EL SERVIDOR
        	        fr2 = new FileReader (archivo2);
        	        br2 = new BufferedReader(fr2);
        	        
        	     // Lectura del fichero
        	         String linea2;
        	         linea2 = br2.readLine();
        	        
        	        
        	         while(linea2!=null) {
        	        	 //Vamos buscando usuario y contrase�a
        	        	lista.add(linea2);
        	        	linea2=br2.readLine();
        	         }
        			br2.close();
        		}
        		
        	 }
        	 linea=br.readLine();
         }
         br.close();
         return lista;
	}
}
