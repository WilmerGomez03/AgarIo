package WebService;

import java.io.IOException;
import java.net.ServerSocket;

import ServerModel.ServerModel;

public class ServerWebGUI {

	public ServerWebGUI() {
		
	}

	 public static void main(String[] args) throws IOException {
				ServerWeb server = new ServerWeb();
	 }
}
