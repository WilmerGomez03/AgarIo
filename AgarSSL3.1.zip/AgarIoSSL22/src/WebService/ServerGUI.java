package WebService;

import java.io.IOException;
import java.net.ServerSocket;

import ServerModel.ServerModel;

public class ServerGUI {

	public ServerGUI() {
		
	}

	 public static void main(String[] args) throws IOException {
				ServerWeb server = new ServerWeb();
	 }
}
